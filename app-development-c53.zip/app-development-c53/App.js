import React, { Component } from 'react';
import { Button, View,Text } from 'react-native';


export class FirstApp extends Component{
  render(){
    return(
        <Button color="red" title="Click Me"></Button>
    )
  }
}

export default class BlueKey extends Component {
  render() {
    return (
      <View style={{marginTop: 50,marginLeft: 120, width: "50%"}}>
        <FirstApp/>
        <Text>My first React Component</Text>
      </View>
    );
  }
}
